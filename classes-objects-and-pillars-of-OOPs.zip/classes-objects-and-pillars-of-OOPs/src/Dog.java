//demonstration of uses of classes and objects
public class Dog{
	String name;
	String breed;
	int age;
	String colour;
	public Dog(String name, String breed, int age, String colour) {
		this.name = name;
		this.breed=breed;
		this.age=age;
		this.colour=colour;
	}
	public String Name() {
		return name;
	}
	public String Breed() {
		return breed;
	}
	public int Age() {
		return age;
	}
	public String Colour() {
		return colour;
	}
	@Override
	public String toString() {
		return("hi my name is "+name+".\nMy Breed, age and colour are "+this.Breed()+","+this.Age()+","+this.Colour()+".");
	}
	public static void main(String[] args) {
		Dog scott = new Dog("Scott","papillion",5,"black");
		System.out.println(scott.toString());
	}
}