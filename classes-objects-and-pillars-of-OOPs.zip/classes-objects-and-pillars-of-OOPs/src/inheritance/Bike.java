package inheritance;
//inheritance
class Bike {
	public int gear;
	public int speed;
	public Bike(int gear, int speed) {
		this.gear=gear;
		this.speed=speed;
	}
	public void applyBrake(int decrement) {
		speed-=decrement;
	}
	public void speedUp(int increment) {
		speed+=increment;
	}
	public String toString() {
		return("no of gears are "+gear+" \nspeed of the Bike is "+speed+".");
	}
}
class MountainBike extends Bike{
	public int seatHeight;
	public MountainBike(int gear, int speed, int startHeight) {
		super(gear, speed);
		seatHeight = startHeight;
	}
	public void seatHeight(int newValue) {
		seatHeight=newValue;
	}
	@Override
	public String toString() {
		return(super.toString()+"\nseat height is "+seatHeight);
	}
}

