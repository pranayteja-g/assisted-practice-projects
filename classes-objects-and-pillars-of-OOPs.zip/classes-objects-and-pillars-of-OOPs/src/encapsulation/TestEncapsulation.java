package encapsulation;

public class TestEncapsulation {
	public static void main(String[] args) {
		Encapsulate obj= new Encapsulate();
		obj.setName("bob");
		obj.setAge(26);
		obj.setRoll(68);
		System.out.println("hello I am "+obj.getName());
		System.out.println("I am "+obj.getAge()+" years old.");
		System.out.println("my roll is "+obj.getRoll());
	}
}
