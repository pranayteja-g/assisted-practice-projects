public class strings {

	public static void main(String[] args) {
		System.out.println("Methods of Strings");      //methods of strings
		
		String sl=new String("Hello World");
		System.out.println(sl.length());

		String sub=new String("Welcome");              //substring
		System.out.println(sub.substring(2));

		String s1="Hello";                             //String Comparison
		String s2="Heldo";
		System.out.println(s1.compareTo(s2));

		String s4="";                                  //IsEmpty
		System.out.println(s4.isEmpty());

		String s5="Hello";                             //toLowerCase
		System.out.println(s1.toLowerCase());
		
		String s6="Heldo";                              //replace
		String replace=s2.replace('d', 'l');
		System.out.println(replace);

		String x="Welcome to Java";                      //equals
		String y="WeLcOmE tO JaVa";
		System.out.println(x.equals(y));
 
		System.out.println("\n");
		System.out.println("Creating StringBuffer");
		
		StringBuffer s=new StringBuffer("Welcome to Java!"); //Creating StringBuffer and append method
		s.append("Enjoy your learning");
		System.out.println(s);

		s.insert(0, 'w');                          //insert method
		System.out.println(s);

		StringBuffer sb=new StringBuffer("Hello");   //replace method
		sb.replace(0, 2, "hEl");
		System.out.println(sb);

		sb.delete(0, 1);                           //delete method
		System.out.println(sb);
		
		System.out.println("\n");                        //StringBuilder
		System.out.println("Creating StringBuilder");
		StringBuilder sb1=new StringBuilder("Happy");
		sb1.append("Learning");
		System.out.println(sb1);

		System.out.println(sb1.delete(0, 1));

		System.out.println(sb1.insert(1, "Welcome"));

		System.out.println(sb1.reverse());
				
		//conversion	
		System.out.println("\n");
		System.out.println("Conversion of Strings to StringBuffer and StringBuilder");
		
		String str = "Hello"; 
         
        StringBuffer sbr = new StringBuffer(str);                   // conversion from String object to StringBuffer 
        sbr.reverse(); 
        System.out.println("String to StringBuffer");
        System.out.println(sbr); 
          
        // conversion from String object to StringBuilder 
        StringBuilder sbl = new StringBuilder(str); 
        sbl.append("world"); 
        System.out.println("String to StringBuilder");
        System.out.println(sbl);              		
	}
}

