package constructors;
//parameterized constructor
public class person {
	public static void main(String[] args) {
		PersonDetails persondetail=new PersonDetails(50000,5000);
		
	}
}
