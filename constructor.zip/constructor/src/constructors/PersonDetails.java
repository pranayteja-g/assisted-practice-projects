package constructors;

//parameterized constructor
public class PersonDetails {
	
	PersonDetails(int salary, int bonus) {
		System.out.println("final amount is :" +(bonus+salary));
	}

}
