package constructors;

//default constructor
public class defaultPerson {
	public static void main(String[] args) {
		defaultPersonDetails persondetail=new defaultPersonDetails();
		
	}

}